module.exports = async function shoppingHandler(sock, mek, command, args, from) {
    const queryBarang = args.slice(1).join(' ');
    if (!queryBarang) {
        await sock.sendMessage(from, { text: '⚠️ Contoh: .cari oli motul 5100' }, { quoted: mek });
        return;
    }
    const encodedQuery = encodeURIComponent(queryBarang);
    const linkShopee = `https://shopee.co.id/search?keyword=${encodedQuery}&sortBy=sales`;
    const linkTokped = `https://www.tokopedia.com/search?st=product&q=${encodedQuery}&rt=4,5`;

    const replyText = `🛍️ *REKOMENDASI PRODUK TERLARIS*\n\n` +
                      `📦 Barang: *${queryBarang}*\n` +
                      `⭐ Rating: *4.9+ (Terlaris)*\n\n` +
                      `🟠 Shopee:\n${linkShopee}\n\n` +
                      `🟢 Tokopedia:\n${linkTokped}`;
    await sock.sendMessage(from, { text: replyText }, { quoted: mek });
};
