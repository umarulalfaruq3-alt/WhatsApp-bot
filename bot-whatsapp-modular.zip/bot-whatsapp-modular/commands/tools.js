module.exports = async function toolsHandler(sock, mek, command, args, from) {
    if (command === '.textstiker' || command === '.ts') {
        const teks = args.slice(1).join(' ');
        if (!teks) {
            await sock.sendMessage(from, { text: 'Contoh: .ts bejirr gawat' }, { quoted: mek });
            return;
        }
        await sock.sendMessage(from, { text: `Memproses stiker teks: "${teks}"...` }, { quoted: mek });
    }
};
