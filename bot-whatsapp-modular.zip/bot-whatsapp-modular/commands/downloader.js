const axios = require('axios');

module.exports = async function downloaderHandler(sock, mek, command, args, from) {
    const url = args[1];
    if (!url) {
        await sock.sendMessage(from, { text: `Tolong sertakan link!\nContoh: ${command} https://...` }, { quoted: mek });
        return;
    }

    if (command === '.ig' || command === '.instagram') {
        try {
            await sock.sendMessage(from, { text: '⏳ Mengambil media Instagram...' }, { quoted: mek });
            const res = await axios.get(`https://api.siputzx.my.id/api/d/igdl?url=${encodeURIComponent(url)}`);
            const dlUrl = res.data.data[0].url;
            await sock.sendMessage(from, { video: { url: dlUrl }, caption: '✅ Berhasil download Instagram!' }, { quoted: mek });
        } catch (err) {
            await sock.sendMessage(from, { text: 'Gagal mendownload media Instagram.' }, { quoted: mek });
        }
    } else if (command === '.tiktok') {
        await sock.sendMessage(from, { text: '⏳ Mengunduh video TikTok...' }, { quoted: mek });
    }
};
