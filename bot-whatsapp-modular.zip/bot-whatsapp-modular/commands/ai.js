const axios = require('axios');

module.exports = async function aiHandler(sock, mek, command, args, from) {
    const queryAi = args.slice(1).join(' ');
    if (!queryAi) {
        await sock.sendMessage(from, { text: 'Mau tanya apa ke AI?\nContoh: .ai Kenapa motor karbu bisa banjir?' }, { quoted: mek });
        return;
    }

    try {
        await sock.sendMessage(from, { text: '🤖 Sedang berpikir...' }, { quoted: mek });
        const response = await axios.get(`https://api.siputzx.my.id/api/ai/gemini?prompt=${encodeURIComponent(queryAi)}`);
        const jawaban = response.data.data || response.data.result;
        await sock.sendMessage(from, { text: `🤖 *AI Assistant:*\n\n${jawaban}` }, { quoted: mek });
    } catch (e) {
        await sock.sendMessage(from, { text: 'Maaf, layanan AI sedang gangguan.' }, { quoted: mek });
    }
};
